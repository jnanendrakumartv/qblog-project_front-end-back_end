export const REG='REG';
export const LOGIN='LOGIN';

